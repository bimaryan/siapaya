<nav class="bg-gray-800 p-4 fixed top-0 left-0 w-full">
    <div class="container mx-auto flex justify-between items-center">
        <!-- Logo / App Name -->
        <a href="{{route('dashboard.index')}}" class="text-white text-xl font-bold">
            Siapaya
        </a>
    </div>
</nav>
