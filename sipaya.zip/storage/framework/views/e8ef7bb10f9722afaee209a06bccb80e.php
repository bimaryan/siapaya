<?php $__env->startSection('content'); ?>
    <!-- Daftar Pesan -->
    <div class="w-full max-w-screen-xl p-4 space-y-4 mt-10">
        <div class="bg-gray-800 text-white rounded-lg shadow-lg p-4 w-full max-w-screen-xl text-center">
            <h1 class="text-2xl font-bold">Semua Pesan</h1>
        </div>

        <?php $__empty_1 = true; $__currentLoopData = $pesan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="bg-gray-800 text-white p-4 rounded-lg shadow-md">
                <p class="mt-2 text-xl text-gray-100"><?php echo e($item->pesan); ?></p>
                <p class="text-sm text-gray-300"><?php echo e($item->created_at->format('d M Y, H:i')); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="text-center text-gray-400">
                <p>Tidak ada pesan anonim untuk saat ini.</p>
            </div>
        <?php endif; ?>

        <div class="mt-3">
            <?php echo e($pesan->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Pages.Pengguna.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bima/siapaya/resources/views/Pages/Pengguna/Semuapesan/index.blade.php ENDPATH**/ ?>