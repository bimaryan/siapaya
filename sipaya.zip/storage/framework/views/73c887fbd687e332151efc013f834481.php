<?php $__env->startSection('content'); ?>
    <div class="w-full max-w-screen-xl p-4 space-y-4 mt-10">
        <div class="bg-gray-800 text-white rounded-lg shadow-lg p-6 w-full max-w-screen-xl">
            <h1 class="text-2xl font-bold mb-4">Kirim Pesan ke <?php echo e($name); ?></h1>

            <?php if($errors->any()): ?>
                <div class="text-red-500 text-sm mb-4">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($error); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

            <?php if(session('Berhasil')): ?>
                <div class="mt-4 text-green-500">
                    <?php echo e(session('Berhasil')); ?>

                </div>
            <?php endif; ?>


            <!-- Pesan Form -->
            <form action="<?php echo e(route('Pesan.update', $name)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="mb-4">
                    <label for="pesan" class="block text-sm text-gray-400 mb-2">Pesan Anda</label>
                    <textarea id="pesan" name="pesan" rows="4"
                        class="w-full px-4 py-2 bg-gray-700 text-white border border-gray-600 rounded-md focus:ring-2 focus:ring-blue-500 focus:outline-none"
                        placeholder="Tulis pesan Anda di sini..."></textarea>
                </div>

                <button type="submit"
                    class="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-md px-6 py-2">
                    Kirim Pesan
                </button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Pages.Pengguna.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bima/siapaya/resources/views/Pages/Pengguna/Pesan/index.blade.php ENDPATH**/ ?>