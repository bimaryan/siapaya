<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <title>Siapaya</title>
</head>

<body>
    <!-- Hero Section -->
    <section class="bg-gray-900 text-white h-screen flex flex-col justify-center items-center">
        <div class="text-center mb-6">
            <h1 class="text-4xl font-bold mb-4">Selamat Datang di Siapaya</h1>
            <p class="text-lg mb-4">Platform untuk berbagi pesan anonim dan komunikasi yang lebih mudah!</p>
            <a href="<?php echo e(route('masuk.index')); ?>"
                class="bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md text-lg">
                Masuk Sekarang
            </a>
        </div>
    </section>

    <!-- Fitur Utama -->
    <section class="py-16 bg-gray-100 mb-10 mt-10">
        <div class="container mx-auto text-center">
            <h2 class="text-3xl font-semibold mb-8">Fitur Utama</h2>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <!-- Fitur 1 -->
                <div class="bg-white p-6 rounded-lg shadow-lg">
                    <i class="fas fa-comments text-4xl text-blue-600 mb-4"></i>
                    <h3 class="text-xl font-semibold mb-2">Pesan Anonim</h3>
                    <p>Berbagi pesan anonim dengan teman-teman Anda, tanpa identitas yang diketahui.</p>
                </div>
                <!-- Fitur 2 -->
                <div class="bg-white p-6 rounded-lg shadow-lg">
                    <i class="fas fa-users text-4xl text-blue-600 mb-4"></i>
                    <h3 class="text-xl font-semibold mb-2">Komunitas</h3>
                    <p>Bergabung dengan komunitas untuk berbagi pemikiran dan berinteraksi dengan orang lain.</p>
                </div>
                <!-- Fitur 3 -->
                <div class="bg-white p-6 rounded-lg shadow-lg">
                    <i class="fas fa-share-alt text-4xl text-blue-600 mb-4"></i>
                    <h3 class="text-xl font-semibold mb-2">Berbagi Mudah</h3>
                    <p>Bagikan pesan Anda dengan mudah melalui media sosial, tanpa repot.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer Section -->
    <footer class="bg-gray-900 text-white py-4">
        <div class="container mx-auto text-center">
            <p>&copy; 2025 Siapaya. Semua hak dilindungi.</p>
            <div class="flex justify-center space-x-4 mt-4">
                <a href="#" class="text-gray-400 hover:text-white">
                    <i class="fab fa-facebook-f"></i>
                </a>
                <a href="#" class="text-gray-400 hover:text-white">
                    <i class="fab fa-twitter"></i>
                </a>
                <a href="#" class="text-gray-400 hover:text-white">
                    <i class="fab fa-instagram"></i>
                </a>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.js"></script>
</body>

</html>
<?php /**PATH /home/bima/siapaya/resources/views/welcome.blade.php ENDPATH**/ ?>