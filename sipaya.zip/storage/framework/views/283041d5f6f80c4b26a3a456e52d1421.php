<footer class="fixed bottom-0 left-0 w-full bg-gray-800 text-white">
    <div class="flex justify-between container mx-auto items-center p-4">
        <!-- Beranda Button -->
        <a href="<?php echo e(route('dashboard.index')); ?>" class="flex flex-col items-center text-gray-300 hover:text-white">
            <i class="fas fa-home text-2xl"></i>
            <span class="text-xs">Beranda</span>
        </a>

        <!-- Pesan Button -->
        <a href="<?php echo e(route('semua-pesan.index')); ?>" class="flex flex-col items-center text-gray-300 hover:text-white">
            <i class="fas fa-comment-dots text-2xl"></i>
            <span class="text-xs">Pesan</span>
        </a>

        <!-- Keluar Button -->
        <form action="<?php echo e(route('keluar.index')); ?>" method="POST" class="flex flex-col items-center">
            <?php echo csrf_field(); ?>
            <button type="submit" class="flex flex-col items-center text-gray-300 hover:text-white">
                <i class="fas fa-sign-out-alt text-2xl"></i>
                <span class="text-xs">Keluar</span>
            </button>
        </form>
    </div>
</footer>
<?php /**PATH /home/bima/siapaya/resources/views/Components/Footer/index.blade.php ENDPATH**/ ?>